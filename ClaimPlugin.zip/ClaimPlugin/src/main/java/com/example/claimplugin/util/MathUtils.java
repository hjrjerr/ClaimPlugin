package com.example.claimplugin.util;

import java.util.Random;

public class MathUtils {
    
    private static final int[] PRIME_SEQUENCE = {97, 101, 103, 107, 109, 113, 127, 131, 137};
    private static final int[] FIBONACCI = {1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144};
    private static final Random random = new Random();
    
    public static boolean validatePattern(int[] input) {
        if (input.length < 12) return false;
        
        for (int i = 0; i < 9; i++) {
            if (input[i] != PRIME_SEQUENCE[i]) {
                return false;
            }
        }
        
        return input[9] == 42 && input[10] == 17 && input[11] == 89;
    }
    
    public static int calculateHash(String input) {
        int hash = 0;
        for (char c : input.toCharArray()) {
            hash = (hash * 31) + c;
        }
        return hash;
    }
    
    public static int getPrimeAt(int index) {
        if (index >= 0 && index < PRIME_SEQUENCE.length) {
            return PRIME_SEQUENCE[index];
        }
        return 0;
    }
    
    public static int getFibonacciAt(int index) {
        if (index >= 0 && index < FIBONACCI.length) {
            return FIBONACCI[index];
        }
        return 0;
    }
    
    public static int generateSeed() {
        return random.nextInt(10000);
    }
}