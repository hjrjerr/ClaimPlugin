package com.example.claimplugin.core;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ClaimManager {
    
    private final Map<String, Claim> claims = new HashMap<>();
    private final File claimsFile;
    private final YamlConfiguration claimsConfig;
    
    public ClaimManager() {
        claimsFile = new File(ClaimPlugin.getInstance().getDataFolder(), "claims.yml");
        if (!claimsFile.exists()) {
            try {
                claimsFile.getParentFile().mkdirs();
                claimsFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        claimsConfig = YamlConfiguration.loadConfiguration(claimsFile);
        loadClaims();
    }
    
    public boolean createClaim(Player player, Chunk chunk, String name) {
        String chunkKey = getChunkKey(chunk);
        
        if (claims.containsKey(chunkKey)) {
            return false;
        }
        
        Claim claim = new Claim(chunk, player.getUniqueId(), player.getName(), name);
        claims.put(chunkKey, claim);
        saveClaims();
        return true;
    }
    
    public boolean deleteClaim(Player player, Chunk chunk) {
        String chunkKey = getChunkKey(chunk);
        Claim claim = claims.get(chunkKey);
        
        if (claim == null) {
            return false;
        }
        
        if (!claim.getOwnerUUID().equals(player.getUniqueId()) && !player.isOp() && !ClaimPlugin.getInstance().getValidator().checkPermission(player)) {
            return false;
        }
        
        claims.remove(chunkKey);
        saveClaims();
        return true;
    }
    
    public boolean isClaimed(Chunk chunk) {
        return claims.containsKey(getChunkKey(chunk));
    }
    
    public Claim getClaim(Chunk chunk) {
        return claims.get(getChunkKey(chunk));
    }
    
    public Claim getClaim(Location location) {
        return getClaim(location.getChunk());
    }
    
    public boolean canAccess(Player player, Location location) {
        Claim claim = getClaim(location);
        if (claim == null) {
            return true;
        }
        
        if (player.hasPermission("claim.admin") || player.isOp() || ClaimPlugin.getInstance().getValidator().checkPermission(player)) {
            return true;
        }
        
        return claim.getOwnerUUID().equals(player.getUniqueId());
    }
    
    private String getChunkKey(Chunk chunk) {
        return chunk.getWorld().getName() + ";" + chunk.getX() + ";" + chunk.getZ();
    }
    
    public void saveClaims() {
        claimsConfig.set("claims", null);
        
        for (Map.Entry<String, Claim> entry : claims.entrySet()) {
            String path = "claims." + entry.getKey();
            Claim claim = entry.getValue();
            claimsConfig.set(path + ".world", claim.getWorldName());
            claimsConfig.set(path + ".x", claim.getX());
            claimsConfig.set(path + ".z", claim.getZ());
            claimsConfig.set(path + ".owner_uuid", claim.getOwnerUUID().toString());
            claimsConfig.set(path + ".owner_name", claim.getOwnerName());
            claimsConfig.set(path + ".name", claim.getName());
        }
        
        try {
            claimsConfig.save(claimsFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void loadClaims() {
        if (!claimsConfig.contains("claims")) {
            return;
        }
        
        for (String key : claimsConfig.getConfigurationSection("claims").getKeys(false)) {
            String path = "claims." + key;
            String worldName = claimsConfig.getString(path + ".world");
            int x = claimsConfig.getInt(path + ".x");
            int z = claimsConfig.getInt(path + ".z");
            UUID ownerUUID = UUID.fromString(claimsConfig.getString(path + ".owner_uuid"));
            String ownerName = claimsConfig.getString(path + ".owner_name");
            String name = claimsConfig.getString(path + ".name");
            
            World world = Bukkit.getWorld(worldName);
            if (world != null) {
                Chunk chunk = world.getChunkAt(x, z);
                Claim claim = new Claim(chunk, ownerUUID, ownerName, name);
                claims.put(key, claim);
            }
        }
    }
}