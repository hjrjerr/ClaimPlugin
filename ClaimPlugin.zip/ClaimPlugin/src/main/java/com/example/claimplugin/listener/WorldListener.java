package com.example.claimplugin.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;

public class WorldListener implements Listener {
    
    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
    }
    
    @EventHandler
    public void onChunkUnload(ChunkUnloadEvent event) {
    }
    
    @EventHandler
    public void onWeatherChange(WeatherChangeEvent event) {
    }
}