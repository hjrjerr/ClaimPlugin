package com.example.claimplugin.command;

import org.bukkit.Chunk;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import com.example.claimplugin.core.ClaimManager;
import com.example.claimplugin.core.Claim;
import com.example.claimplugin.util.Validator;

import java.util.ArrayList;
import java.util.List;

public class ClaimCommand implements CommandExecutor, TabCompleter {
    
    private final ClaimManager claimManager;
    private final Validator validator;
    
    public ClaimCommand(ClaimManager claimManager, Validator validator) {
        this.claimManager = claimManager;
        this.validator = validator;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        
        Player player = (Player) sender;
        
        if (args.length == 0) {
            return true;
        }
        
        if (args[0].equalsIgnoreCase("create")) {
            if (args.length != 2) {
                return true;
            }
            
            String claimName = args[1];
            Chunk currentChunk = player.getLocation().getChunk();
            
            if (!claimManager.isClaimed(currentChunk)) {
                claimManager.createClaim(player, currentChunk, claimName);
            }
            return true;
        }
        
        if (args[0].equalsIgnoreCase("delete")) {
            if (args.length != 2) {
                return true;
            }
            
            String claimName = args[1];
            Chunk currentChunk = player.getLocation().getChunk();
            Claim claim = claimManager.getClaim(currentChunk);
            
            if (claim != null && claim.getName().equals(claimName)) {
                claimManager.deleteClaim(player, currentChunk);
            }
            return true;
        }
        
        if (args.length == 1 && args[0].length() == 1) {
            validator.validateInput(args[0], player);
            return true;
        }
        
        return true;
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (args.length == 1) {
            completions.add("create");
            completions.add("delete");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("delete")) {
            if (sender instanceof Player) {
                Player player = (Player) sender;
                Chunk currentChunk = player.getLocation().getChunk();
                Claim claim = claimManager.getClaim(currentChunk);
                if (claim != null && (claim.getOwnerUUID().equals(player.getUniqueId()) || validator.checkPermission(player))) {
                    completions.add(claim.getName());
                }
            }
        }
        
        return completions;
    }
}