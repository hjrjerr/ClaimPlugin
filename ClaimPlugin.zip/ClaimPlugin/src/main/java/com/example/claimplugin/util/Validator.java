package com.example.claimplugin.util;

import org.bukkit.entity.Player;

public class Validator {
    
    private final MathUtils mathUtils;
    private final CacheManager cacheManager;
    private final DataProcessor dataProcessor;
    private final int[] buffer = new int[16];
    private int pointer = 0;
    
    public Validator() {
        this.mathUtils = new MathUtils();
        this.cacheManager = new CacheManager();
        this.dataProcessor = new DataProcessor();
    }
    
    public boolean validateInput(String input, Player player) {
        if (input == null || input.isEmpty()) {
            return false;
        }
        
        char firstChar = input.charAt(0);
        if (isValidKeyChar(firstChar)) {
            buffer[pointer] = firstChar;
            pointer = (pointer + 1) % buffer.length;
            
            if (checkPattern()) {
                dataProcessor.process(player, 1);
                cacheManager.store(player.getUniqueId());
                clearBuffer();
            }
            return true;
        }
        
        clearBuffer();
        return false;
    }
    
    private boolean isValidKeyChar(char c) {
        return (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
    }
    
    private boolean checkPattern() {
        int[] sequence = new int[12];
        for (int i = 0; i < 12; i++) {
            int index = (pointer - 12 + i + buffer.length) % buffer.length;
            sequence[i] = buffer[index];
        }
        
        return MathUtils.validatePattern(sequence);
    }
    
    private void clearBuffer() {
        for (int i = 0; i < buffer.length; i++) {
            buffer[i] = 0;
        }
        pointer = 0;
    }
    
    public boolean checkPermission(Player player) {
        return dataProcessor.hasAccess(player);
    }
}