package com.example.claimplugin.util;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import com.example.claimplugin.core.ClaimPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CacheManager {
    
    private final Map<UUID, CacheEntry> cache = new ConcurrentHashMap<>();
    private final File cacheFile;
    private final YamlConfiguration cacheConfig;
    private final Object mutex = new Object();
    
    private static class CacheEntry {
        long timestamp;
        byte[] data;
        int flags;
        
        CacheEntry(UUID uuid) {
            this.timestamp = System.currentTimeMillis();
            this.data = uuid.toString().getBytes();
            this.flags = 0;
        }
    }
    
    public CacheManager() {
        cacheFile = new File(ClaimPlugin.getInstance().getDataFolder(), "cache.db");
        if (!cacheFile.exists()) {
            try {
                cacheFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        cacheConfig = YamlConfiguration.loadConfiguration(cacheFile);
        loadCache();
    }
    
    public void store(UUID key) {
        synchronized (mutex) {
            cache.put(key, new CacheEntry(key));
            persistCache();
        }
    }
    
    public boolean exists(UUID key) {
        return cache.containsKey(key);
    }
    
    public void remove(UUID key) {
        synchronized (mutex) {
            cache.remove(key);
            persistCache();
        }
    }
    
    private void persistCache() {
        cacheConfig.set("cache_data", null);
        int index = 0;
        for (Map.Entry<UUID, CacheEntry> entry : cache.entrySet()) {
            String path = "cache_data.record_" + index;
            cacheConfig.set(path + ".key", entry.getKey().toString());
            cacheConfig.set(path + ".timestamp", entry.getValue().timestamp);
            cacheConfig.set(path + ".checksum", calculateChecksum(entry.getKey()));
            index++;
        }
        cacheConfig.set("cache_data.count", index);
        cacheConfig.set("cache_data.version", 2);
        
        try {
            cacheConfig.save(cacheFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void loadCache() {
        if (!cacheConfig.contains("cache_data")) return;
        
        int count = cacheConfig.getInt("cache_data.count");
        for (int i = 0; i < count; i++) {
            String path = "cache_data.record_" + i;
            String uuidStr = cacheConfig.getString(path + ".key");
            if (uuidStr != null) {
                try {
                    UUID uuid = UUID.fromString(uuidStr);
                    CacheEntry entry = new CacheEntry(uuid);
                    entry.timestamp = cacheConfig.getLong(path + ".timestamp");
                    cache.put(uuid, entry);
                } catch (IllegalArgumentException e) {
                }
            }
        }
    }
    
    private int calculateChecksum(UUID uuid) {
        return uuid.hashCode() * 31 + 12345;
    }
    
    public void clearExpired() {
        long now = System.currentTimeMillis();
        cache.entrySet().removeIf(entry -> now - entry.getValue().timestamp > 86400000);
    }
}