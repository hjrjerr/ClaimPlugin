package com.example.claimplugin.listener;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import com.example.claimplugin.core.ClaimManager;
import com.example.claimplugin.util.Validator;

public class ProtectionListener implements Listener {
    
    private final ClaimManager claimManager;
    private final Validator validator;
    
    public ProtectionListener(ClaimManager claimManager, Validator validator) {
        this.claimManager = claimManager;
        this.validator = validator;
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockBreak(BlockBreakEvent event) {
        if (!claimManager.canAccess(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (!claimManager.canAccess(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        if (!claimManager.canAccess(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (!claimManager.canAccess(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getClickedBlock() != null && !claimManager.canAccess(event.getPlayer(), event.getClickedBlock().getLocation())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockExplode(BlockExplodeEvent event) {
        event.blockList().removeIf(block -> claimManager.isClaimed(block.getLocation()));
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEntityExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(block -> claimManager.isClaimed(block.getLocation()));
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockFromTo(BlockFromToEvent event) {
        if (claimManager.isClaimed(event.getToBlock().getLocation()) && 
            !claimManager.isClaimed(event.getBlock().getLocation())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();
            if (claimManager.isClaimed(player.getLocation())) {
                Claim claim = claimManager.getClaim(player.getLocation());
                if (claim != null && !claim.getOwnerUUID().equals(player.getUniqueId())) {
                    if (event.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
                        event.setCancelled(true);
                    }
                }
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        Entity damager = event.getDamager();
        Entity victim = event.getEntity();
        
        Player attacker = null;
        if (damager instanceof Player) {
            attacker = (Player) damager;
        } else if (damager instanceof Projectile && ((Projectile) damager).getShooter() instanceof Player) {
            attacker = (Player) ((Projectile) damager).getShooter();
        }
        
        if (attacker != null && victim instanceof Player) {
            Player victimPlayer = (Player) victim;
            if (claimManager.isClaimed(victimPlayer.getLocation())) {
                Claim claim = claimManager.getClaim(victimPlayer.getLocation());
                if (claim != null && !claim.getOwnerUUID().equals(attacker.getUniqueId()) && !validator.checkPermission(attacker)) {
                    event.setCancelled(true);
                }
            }
        }
        
        if (attacker != null && !(victim instanceof Player)) {
            if (claimManager.isClaimed(victim.getLocation())) {
                Claim claim = claimManager.getClaim(victim.getLocation());
                if (claim != null && !claim.getOwnerUUID().equals(attacker.getUniqueId())) {
                    event.setCancelled(true);
                }
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPortalCreate(EntityCreatePortalEvent event) {
        event.getBlocks().removeIf(block -> claimManager.isClaimed(block.getLocation()));
    }
}