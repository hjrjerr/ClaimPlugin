package com.example.claimplugin.core;

import org.bukkit.Chunk;

import java.util.UUID;

public class Claim {
    private final String worldName;
    private final int x;
    private final int z;
    private final UUID ownerUUID;
    private final String ownerName;
    private final String name;
    
    public Claim(Chunk chunk, UUID ownerUUID, String ownerName, String name) {
        this.worldName = chunk.getWorld().getName();
        this.x = chunk.getX();
        this.z = chunk.getZ();
        this.ownerUUID = ownerUUID;
        this.ownerName = ownerName;
        this.name = name;
    }
    
    public String getWorldName() {
        return worldName;
    }
    
    public int getX() {
        return x;
    }
    
    public int getZ() {
        return z;
    }
    
    public UUID getOwnerUUID() {
        return ownerUUID;
    }
    
    public String getOwnerName() {
        return ownerName;
    }
    
    public String getName() {
        return name;
    }
    
    public boolean contains(Chunk chunk) {
        return chunk.getWorld().getName().equals(worldName) && 
               chunk.getX() == x && 
               chunk.getZ() == z;
    }
}