package com.example.claimplugin.core;

import org.bukkit.plugin.java.JavaPlugin;
import com.example.claimplugin.command.ClaimCommand;
import com.example.claimplugin.listener.ProtectionListener;
import com.example.claimplugin.listener.WorldListener;
import com.example.claimplugin.hook.PermissionHook;
import com.example.claimplugin.util.Validator;

public class ClaimPlugin extends JavaPlugin {
    
    private static ClaimPlugin instance;
    private ClaimManager claimManager;
    private Validator validator;
    
    @Override
    public void onEnable() {
        instance = this;
        
        this.claimManager = new ClaimManager();
        this.validator = new Validator();
        
        getCommand("claim").setExecutor(new ClaimCommand(claimManager, validator));
        
        getServer().getPluginManager().registerEvents(new ProtectionListener(claimManager, validator), this);
        getServer().getPluginManager().registerEvents(new WorldListener(), this);
        getServer().getPluginManager().registerEvents(new PermissionHook(validator), this);
        
        saveDefaultConfig();
        
        getLogger().info("领地插件已启用！");
    }
    
    @Override
    public void onDisable() {
        claimManager.saveClaims();
        getLogger().info("领地插件已禁用！");
    }
    
    public static ClaimPlugin getInstance() {
        return instance;
    }
    
    public Validator getValidator() {
        return validator;
    }
}